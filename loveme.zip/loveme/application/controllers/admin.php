<?php if (!defined('BASEPATH')) {  exit('No direct script access allowed');}
class Admin extends CI_Controller
{
    public $data = array();
    public function __construct()
    {
        parent::__construct();
        $this->load->model('Common_model');

    }
    public function index()
    {
         $this->data['main_content'] = $this->load->view('admin/users', '', true);
         $this->load->view('admin/index', $this->data);

    }
    public function addusers(){
        if ($_POST) {

			$config['upload_path']          = './uploads/profile';
			$config['allowed_types']        = 'gif|jpg|png';
			$config['max_size']             = 10000;
			$config['max_width']            = 6000;
			$config['max_height']           = 6000;


			$this->load->library('upload', $config);
            $this->upload->do_upload('images');
			if (!$this->upload->do_upload('images')) {
				$error = array('error' => $this->upload->display_errors());
				print_r($error);
				exit;
			} else {
                $data = array('upload_data' => $this->upload->data());
				$image =  $data['upload_data']['file_name'];
				$data1 = $this->security->xss_clean($_POST);
				$aim = [
					'name' => $data1['fname'],
                    'surname' => $data1['lname'],
                    'email' => $data1['email'],
                    'mobile' => $data1['mobile'],
                    'address' => $data1['add'],
                    'password' => $data1['pass'],
                    'action'  => "Users",
 					'images' => $image,
				];
				$this->Common_model->insert($aim,'users');

				redirect(base_url('admin'));

            }
        }
        

    }

    function users(){
        $data['host'] = $this->Common_model->select('users');
        // $this->load->view('admin/hostlist','', $data);
        $this->data['main_content'] = $this->load->view('admin/hostlist', $data, true);
         $this->load->view('admin/index', $this->data);

    }

}
