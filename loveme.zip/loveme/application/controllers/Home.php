<?php if (!defined('BASEPATH')) { exit('No direct script access allowed'); }

class Home extends CI_Controller
{
    public $data = array();
    public function __construct()
    {
        parent::__construct();
        $this->load->model('Common_model');
        $this->load->model('mod_login');
        // $this->get_config();
    }
    public function index()
    {
        $this->load->view('login');
    }
    public function finduser()
    {
        if ($_POST) {
            $name = $_POST['Name'];
            $email = $_POST['Email'];
            $pass = $_POST['Password'];

            $data = $this->mod_login->get_admin($name, $email, $pass);

            if ($name == $data[0]['name'] && $pass == $data[0]['password'] && $email == $data[0]['email'] && 'admin' == $data[0]['action']) {
                redirect(base_url('Admin/index'));
            } elseif ($name == $data[0]['name'] && $pass == $data[0]['password'] && $email == $data[0]['email'] && 'users' == $data[0]['action']) {
                redirect(base_url("Users/index"));
            } else {
                redirect(base_url('Home/index/'));
            }
        }
    }
}
