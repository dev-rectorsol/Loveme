<?php if (!defined('BASEPATH')) { exit('No direct script access allowed');
}
class Users extends CI_Controller
{
    public $data = array();
    public function __construct()
    {
        parent::__construct();
        $this->load->model('Common_model');

    }
    public function index()
    {
         $this->data['main_content'] = $this->load->view('users/users', '', true);
         $this->load->view('users/index', $this->data);

    }

}
