<?php

class mod_login extends CI_Model
{
    public function get_admin($name, $email ,$pass)
    {
        $this->db->select('*');
        $this->db->from('users');
        $this->db->where('name', $name);
        $this->db->where('email', $email);
        $this->db->where('password', $pass);
        $query = $this->db->get();
        return  $query->result_array();
    }
}
