<link rel="apple-touch-icon" sizes="76x76" href="<?php echo base_url();  ?>/assets/img/apple-icon.png">
<link rel="icon" type="image/png" href="<?php echo base_url();  ?>/assets/img/favicon.png">
<link rel="canonical" href="https://www.creative-tim.com/product/material-dashboard-pro" />
<link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700|Roboto+Slab:400,700|Material+Icons" />
<link rel="stylesheet" href="<?php echo base_url();  ?>/maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css" />
<!-- CSS Files -->
<link href="<?php echo base_url();  ?>/assets/css/material-dashboard.min1c51.css?v=2.1.2" rel="stylesheet" />
<!-- CSS Just for demo purpose, don't include it in your project -->
<link href="<?php echo base_url();  ?>/assets/demo/demo.css" rel="stylesheet" />


<!-- <link rel="stylesheet" type="text/css" href="http://ajax.aspnetcdn.com/ajax/jquery.dataTables/1.9.0/css/jquery.dataTables.css"> -->
<!-- <link rel="stylesheet" type="text/css" href="http://ajax.aspnetcdn.com/ajax/jquery.dataTables/1.9.0/css/jquery.dataTables_themeroller.css"> -->
